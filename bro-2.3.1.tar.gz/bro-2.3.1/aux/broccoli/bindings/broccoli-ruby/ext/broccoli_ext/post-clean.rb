
File.delete 'mkmf.log' if File.exists? 'mkmf.log'
File.delete 'Makefile' if File.exists? 'Makefile'